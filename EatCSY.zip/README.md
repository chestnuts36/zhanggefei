# 吃掉催逝员

_🦌 网页小游戏 🥛_

</div>


## 简介

小游戏：吃掉催逝员（修改于EatKano）

链接：https://await591.github.io/EatCSY/index.html

## 原项目

线上版本：https://xingye.me/game/eatkano/index.php

Github Page：https://arcxingye.github.io/EatKano/index.html

## Update log

#2022 // 1 // 24 // 23:19 // 修改点击音效音量大小

#2022 // 1 // 24 // 23:32 // 修改点击音效素材内容

#2022 // 1 // 25 // 14:30 // 修改开幕字体大小/添加改前与改后开源项目跳转链接

## 需要反馈?

邮箱：Await591@Outlook.com
